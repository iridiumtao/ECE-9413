"""
Assignment 2 student implementation reference skeleton.

This file documents the frozen student-facing API.
Only 32-bit kernels are compulsory in the base track.
64-bit and 128-bit kernels are intentionally left unimplemented here.
"""

from __future__ import annotations

import functools

import jax
jax.config.update("jax_enable_x64", True)
import jax.numpy as jnp


# -----------------------------------------------------------------------------
# 32-bit primitives (compulsory)
# -----------------------------------------------------------------------------

def mod_add_32(a, b, q):
    """Return (a + b) mod q for the 32-bit track."""
    a64 = jnp.asarray(a, dtype=jnp.uint64)
    b64 = jnp.asarray(b, dtype=jnp.uint64)
    q64 = jnp.asarray(q, dtype=jnp.uint64)
    return jnp.asarray((a64 + b64) % q64, dtype=jnp.uint32)


def mod_sub_32(a, b, q):
    """Return (a - b) mod q for the 32-bit track."""
    a64 = jnp.asarray(a, dtype=jnp.uint64)
    b64 = jnp.asarray(b, dtype=jnp.uint64)
    q64 = jnp.asarray(q, dtype=jnp.uint64)
    return jnp.asarray((a64 + q64 - b64) % q64, dtype=jnp.uint32)


def mod_mul_32(a, b, q):
    """Return (a * b) mod q for the 32-bit track."""
    a64 = jnp.asarray(a, dtype=jnp.uint64)
    b64 = jnp.asarray(b, dtype=jnp.uint64)
    q64 = jnp.asarray(q, dtype=jnp.uint64)
    return jnp.asarray((a64 * b64) % q64, dtype=jnp.uint32)


# -----------------------------------------------------------------------------
# 64-bit primitives (optional, left for future implementation)
# -----------------------------------------------------------------------------

def mod_add_64(a, b, q):
    """Optional 64-bit modular add kernel."""
    # TODO(student): implement when enabling 64-bit track.
    raise NotImplementedError


def mod_sub_64(a, b, q):
    """Optional 64-bit modular subtract kernel."""
    # TODO(student): implement when enabling 64-bit track.
    raise NotImplementedError


def mod_mul_64(a, b, q):
    """Optional 64-bit modular multiply kernel."""
    # TODO(student): implement when enabling 64-bit track.
    raise NotImplementedError


# -----------------------------------------------------------------------------
# 128-bit primitives (optional, left for future implementation)
# -----------------------------------------------------------------------------

def mod_add_128(a, b, q):
    """Optional 128-bit modular add kernel."""
    # TODO(student): implement when enabling 128-bit track.
    raise NotImplementedError


def mod_sub_128(a, b, q):
    """Optional 128-bit modular subtract kernel."""
    # TODO(student): implement when enabling 128-bit track.
    raise NotImplementedError


def mod_mul_128(a, b, q):
    """Optional 128-bit modular multiply kernel."""
    # TODO(student): implement when enabling 128-bit track.
    raise NotImplementedError


# -----------------------------------------------------------------------------
# Frozen dispatch API
# -----------------------------------------------------------------------------

def mod_add(a, b, q, *, bit_width=32):
    if int(bit_width) == 32:
        return mod_add_32(a, b, q)
    if int(bit_width) == 64:
        return mod_add_64(a, b, q)
    if int(bit_width) == 128:
        return mod_add_128(a, b, q)
    raise ValueError(f"Unsupported bit_width={bit_width}")


def mod_sub(a, b, q, *, bit_width=32):
    if int(bit_width) == 32:
        return mod_sub_32(a, b, q)
    if int(bit_width) == 64:
        return mod_sub_64(a, b, q)
    if int(bit_width) == 128:
        return mod_sub_128(a, b, q)
    raise ValueError(f"Unsupported bit_width={bit_width}")


def mod_mul(a, b, q, *, bit_width=32):
    if int(bit_width) == 32:
        return mod_mul_32(a, b, q)
    if int(bit_width) == 64:
        return mod_mul_64(a, b, q)
    if int(bit_width) == 128:
        return mod_mul_128(a, b, q)
    raise ValueError(f"Unsupported bit_width={bit_width}")


def mle_update_32(zero_eval, one_eval, target_eval, *, q):
    """Compulsory 32-bit MLE update.

    Linear interpolation: result = zero_eval + target_eval * (one_eval - zero_eval) mod q.
    Composed from mod_sub_32, mod_mul_32, mod_add_32 — each handles its own overflow
    and underflow safety via uint64 promotion. Plain array operations broadcast across
    array zero_eval / one_eval inputs and a scalar target_eval challenge.
    """
    diff = mod_sub_32(one_eval, zero_eval, q)        # (one - zero) mod q
    scaled = mod_mul_32(target_eval, diff, q)         # target * (one - zero) mod q
    return mod_add_32(zero_eval, scaled, q)           # zero + target * (one - zero) mod q


def mle_update_64(zero_eval, one_eval, target_eval, *, q):
    """Optional 64-bit MLE update."""
    # TODO(student): implement when enabling 64-bit track.
    raise NotImplementedError


def mle_update_128(zero_eval, one_eval, target_eval, *, q):
    """Optional 128-bit MLE update."""
    # TODO(student): implement when enabling 128-bit track.
    raise NotImplementedError


def mle_update(zero_eval, one_eval, target_eval, *, q, bit_width=32):
    if int(bit_width) == 32:
        return mle_update_32(zero_eval, one_eval, target_eval, q=q)
    if int(bit_width) == 64:
        return mle_update_64(zero_eval, one_eval, target_eval, q=q)
    if int(bit_width) == 128:
        return mle_update_128(zero_eval, one_eval, target_eval, q=q)
    raise ValueError(f"Unsupported bit_width={bit_width}")


@functools.partial(jax.jit, static_argnames=("expression", "num_rounds"))
def sumcheck_32(eval_tables, *, q, expression, challenges, num_rounds):
    """Compulsory 32-bit sumcheck path."""
    degree = max(len(term) for term in expression)

    # OPT-03 (D-02): only materialize tables for variables actually used by the
    # expression. tests/case_utils.py:31-61 always loads all 6 VARIABLE_NAMES
    # regardless of the expression, so without this filter we slice and fold up
    # to 5 unused 2^num_rounds tables every round.
    used_vars = set().union(*expression)
    tables = {v: jnp.asarray(eval_tables[v], dtype=jnp.uint32) for v in used_vars}

    round_evals_list = []

    for i in range(num_rounds):
        # Pre-compute evens/odds once per round; reused in the v-loop and fold step.
        evens = {var: tbl[::2]  for var, tbl in tables.items()}
        odds  = {var: tbl[1::2] for var, tbl in tables.items()}
        g_i_evals = []

        for v in range(degree + 1):
            g_i_at_v = jnp.asarray(0, dtype=jnp.uint64)

            for term in expression:
                if v == 0:
                    # t=0 shortcut: even-indexed entries are the zero-eval side directly.
                    term_product = evens[term[0]]
                    for var in term[1:]:
                        term_product = mod_mul_32(term_product, evens[var], q)
                elif v == 1:
                    # t=1 shortcut: odd-indexed entries are the one-eval side directly.
                    term_product = odds[term[0]]
                    for var in term[1:]:
                        term_product = mod_mul_32(term_product, odds[var], q)
                elif v == 2:
                    # OPT-04 (D-04): no-mul MLE shortcut for v=2.
                    # mle_update_32(z, o, 2) = z + 2*(o - z) = 2*o - z (mod q).
                    # Single uint64 reduction avoids the chained mod_sub/mod_mul/mod_add
                    # path of mle_update_32 (3 separate `% q` reductions).
                    q64 = jnp.asarray(q, dtype=jnp.uint64)
                    z64 = evens[term[0]].astype(jnp.uint64)
                    o64 = odds[term[0]].astype(jnp.uint64)
                    term_product = ((2*o64 + q64 - z64) % q64).astype(jnp.uint32)
                    for var in term[1:]:
                        z64_v = evens[var].astype(jnp.uint64)
                        o64_v = odds[var].astype(jnp.uint64)
                        factor = ((2*o64_v + q64 - z64_v) % q64).astype(jnp.uint32)
                        term_product = mod_mul_32(term_product, factor, q)
                elif v == 3:
                    # OPT-04 (D-04): no-mul MLE shortcut for v=3.
                    # mle_update_32(z, o, 3) = z + 3*(o - z) = 3*o - 2*z (mod q).
                    # Shift by 2*q64 to keep the subtraction non-negative in uint64.
                    q64 = jnp.asarray(q, dtype=jnp.uint64)
                    z64 = evens[term[0]].astype(jnp.uint64)
                    o64 = odds[term[0]].astype(jnp.uint64)
                    term_product = ((3*o64 + 2*q64 - 2*z64) % q64).astype(jnp.uint32)
                    for var in term[1:]:
                        z64_v = evens[var].astype(jnp.uint64)
                        o64_v = odds[var].astype(jnp.uint64)
                        factor = ((3*o64_v + 2*q64 - 2*z64_v) % q64).astype(jnp.uint32)
                        term_product = mod_mul_32(term_product, factor, q)
                else:
                    # v >= 4: full linear interpolation (used by --enable-challenge32 advanced polys).
                    # D-05: shortcut deferred for v=4,5 until base-track Exp03 is confirmed.
                    v_scalar = jnp.asarray(v, dtype=jnp.uint32)
                    term_product = mle_update_32(
                        evens[term[0]], odds[term[0]], v_scalar, q=q,
                    )
                    for var in term[1:]:
                        factor = mle_update_32(evens[var], odds[var], v_scalar, q=q)
                        term_product = mod_mul_32(term_product, factor, q)

                # Safe uint64 sum: up to 2^20 entries, each < q < 2^32, sum < 2^52 < 2^64.
                term_sum = jnp.sum(term_product.astype(jnp.uint64)) % jnp.asarray(q, dtype=jnp.uint64)
                g_i_at_v = (g_i_at_v + term_sum) % jnp.asarray(q, dtype=jnp.uint64)

            g_i_evals.append(jnp.asarray(g_i_at_v, dtype=jnp.uint32))

        round_evals_list.append(jnp.stack(g_i_evals))

        # Fold all tables using challenges[i]; reuses pre-computed evens/odds.
        if i < len(challenges):
            r = challenges[i]
            tables = {
                var: mle_update_32(evens[var], odds[var], r, q=q)
                for var in tables
            }

    round_evals = jnp.stack(round_evals_list)

    # claim0 = g_0(0) + g_0(1) mod q (D-04).
    claim0 = mod_add_32(round_evals_list[0][0], round_evals_list[0][1], q)

    return claim0, round_evals


def sumcheck_64(eval_tables, *, q, expression, challenges, num_rounds):
    """Optional 64-bit sumcheck path."""
    # TODO(student): implement when enabling 64-bit track.
    raise NotImplementedError


def sumcheck_128(eval_tables, *, q, expression, challenges, num_rounds):
    """Optional 128-bit sumcheck path."""
    # TODO(student): implement when enabling 128-bit track.
    raise NotImplementedError


def sumcheck(eval_tables, *, q, expression, challenges, num_rounds, bit_width=32):
    """Frozen dispatcher entrypoint used by the harness."""
    # Convert expression to tuple-of-tuples so it is hashable as a JIT static arg.
    expression = tuple(tuple(term) for term in expression)
    if int(bit_width) == 32:
        return sumcheck_32(
            eval_tables,
            q=q,
            expression=expression,
            challenges=challenges,
            num_rounds=num_rounds,
        )
    if int(bit_width) == 64:
        return sumcheck_64(
            eval_tables,
            q=q,
            expression=expression,
            challenges=challenges,
            num_rounds=num_rounds,
        )
    if int(bit_width) == 128:
        return sumcheck_128(
            eval_tables,
            q=q,
            expression=expression,
            challenges=challenges,
            num_rounds=num_rounds,
        )
    raise ValueError(f"Unsupported bit_width={bit_width}")
